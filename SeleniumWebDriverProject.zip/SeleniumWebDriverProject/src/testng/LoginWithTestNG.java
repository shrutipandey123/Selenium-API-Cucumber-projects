package testng;

import java.util.concurrent.TimeUnit;
import static org.testng.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LoginWithTestNG {

	//No need of public static void main in testng
	
	//this should be public so accessible in whole script
	public WebDriver driver;
	
	//==============Setup================
	
	@BeforeTest
	public void setUp() {

		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");

		// open browser
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// open url
		driver.get("http://zero.webappsecurity.com/");
	}

	//===============Test================
	
	@Test
	public void LoginTest() {

		//login Test Case
		driver.findElement(By.xpath("//button[@id='signin_button']")).click();
		driver.findElement(By.xpath("//input[@name ='user_login' ]")).sendKeys("username");
		driver.findElement(By.xpath("//input[contains(@id,'password')]")).sendKeys("password");
		driver.findElement(By.cssSelector("[name = 'submit']")).click();
		driver.findElement(By.cssSelector("button#details-button")).click();
		driver.findElement(By.id("proceed-link")).click();
		assertEquals(driver.getTitle(),"Zero - Account Summary");

	}


	//==============cleanup=============
	
	@AfterTest
	public void cleanUp() {

		//logout
		driver.findElement(By.xpath(".//body/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[3]/a[1]")).click();
		driver.findElement(By.xpath("//a[contains(@id,'logout')]")).click();


		//close driver and quit
		driver.close();
		driver.quit();

	}


}
