package SeleniumWebDriverAdvanced;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FileUpload {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		
		//Maximize window
		driver.manage().window().maximize();
		
		//Implicit Wait
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		//open url
		driver.get("http://the-internet.herokuapp.com/upload");
		
		//identify element
		WebElement uploadButton = driver.findElement(By.id("file-upload"));
		
		//add a file
		uploadButton.sendKeys("C:\\Users\\Administrator\\Desktop\\file.txt");
		
		//click on upload button
		driver.findElement(By.id("file-submit")).click();
		
		assertEquals(driver.findElement(By.id("uploaded-files")).getText(), "file.txt");
		
		
		driver.close();
		driver.quit();
	}

}
