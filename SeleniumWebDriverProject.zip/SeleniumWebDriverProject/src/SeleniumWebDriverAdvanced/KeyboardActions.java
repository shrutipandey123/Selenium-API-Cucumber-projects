package SeleniumWebDriverAdvanced;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class KeyboardActions {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		
		//Maximize window
		driver.manage().window().maximize();
		
		//Implicit Wait
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		//open url
		driver.get("https://www.google.com/");
		
		
		Actions act = new Actions(driver);
		WebElement search =  driver.findElement(By.name("q"));
		
		//Keyboard
		search.sendKeys("Selenium");
		search.sendKeys(Keys.ENTER);
		//just to combine everything ---- not necessary.
		//act.build().perform();
		
		
		//pressing tab and enter button of keyboard
		act.sendKeys(Keys.TAB);
		act.sendKeys(Keys.ENTER);
		act.build().perform();
		
		//Multiple actions by key storks
		//Action Interface ======> this not Actions Class
		//keydown is I am Pressing the key
		//kryup is release
		//doubleclick = do left click twice
		//contextclick ==Right click
		Action kbEvents = act.keyDown(search,Keys.SHIFT).sendKeys("Java COde geeks")
				.keyUp(search, Keys.SHIFT).doubleClick().contextClick().build();
		kbEvents.perform();
	
		
		
		driver.close();
		driver.quit();
	}

}
