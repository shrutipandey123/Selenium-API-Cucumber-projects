package SeleniumWebDriverAdvanced;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseHover {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		
		//Maximize window
		driver.manage().window().maximize();
		
		//Implicit Wait
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		//open url
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login");
		
		//login to application
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		driver.findElement(By.id("txtPassword")).sendKeys("admin123");
		driver.findElement(By.id("btnLogin")).click();

		Actions act = new Actions(driver);
		
		//identify hovering elements
		WebElement admin = driver.findElement(By.id("menu_admin_viewAdminModule"));
		WebElement usermgt = driver.findElement(By.id("menu_admin_UserManagement"));
		WebElement users = driver.findElement(By.id("menu_admin_viewSystemUsers"));

		//per actions on element one by one
		act.moveToElement(admin).build().perform();
		act.moveToElement(usermgt).build().perform();
		act.moveToElement(users).click().build().perform();

		//OR we can do all in one line
		
		//act.moveToElement(admin).moveToElement(usermgt).moveToElement(users).click().build().perform();
		
		
		
		driver.close();
		driver.quit();
		
	}

}
