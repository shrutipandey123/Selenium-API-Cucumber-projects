package SeleniumWebDriverAdvanced;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Resizing {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");

		//open browser
		WebDriver driver = new ChromeDriver();

		//Maximize window
		driver.manage().window().maximize();

		//Implicit Wait
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		//open url
		driver.get("https://jqueryui.com/resizable/");

		//create object of Actions class
		Actions act = new Actions(driver);

		//switch to frame
		driver.switchTo().frame(0);

		//identify slider element
		WebElement resizer = driver.findElement(By.xpath("//*[@id='resizable']/div[3]"));


		//resize the box
		//method1
		act.dragAndDropBy(resizer, 10, 20).build().perform();
		Thread.sleep(3000); 
		//method2
		act.moveToElement(resizer).dragAndDropBy(resizer, 25, 30).build().perform();
		Thread.sleep(3000); 
		driver.close();
		driver.quit();
	}

}
