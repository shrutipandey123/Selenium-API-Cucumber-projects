/**********************************************************************************************************************
Tester Name   : Shruti Pandey                   ClassName    : W3SchoolsConfirmPopupHandle

Project Name  : Assignment3					    Scenario     : 2

Version       : 1.0

Date Created  : 30/12/2021                      Date Updated :


 ************************************************************************************************************************/

package assignments;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class W3SchoolsConfirmPopupHandle_2 {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");

		//open browser
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		//open url
		driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_confirm");

		//wait till confirm pop up displays
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//switch to frame to access TRY IT button
		WebElement  iFrame1 =  driver.findElement(By.id("iframeResult"));
		driver.switchTo().frame(iFrame1);
		
		//clicking on OK -----Accept
		driver.findElement(By.xpath("//button[contains(text(),'Try it')]")).click();
		Alert w3Confirm = driver.switchTo().alert();
		String confirmText = w3Confirm.getText();                                                 //getText()
		System.out.println("The Text on the confirmation popup of page is :" +confirmText);
		assertEquals(confirmText, "Press a button!","Confirmation Test Failed");
		
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		w3Confirm.accept();
		System.out.println("Confirm popup Handled Sucessfully");
		
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// clicking on Cancel -----Dismiss
		driver.findElement(By.xpath("//button[contains(text(),'Try it')]")).click();
		Alert w3CancelConfirm = driver.switchTo().alert();
		String conText = w3CancelConfirm.getText(); // getText()
		System.out.println("The Text on the confirmation popup of page is :" + conText);
		assertEquals(conText, "Press a button!", "Confirmation Test Failed");
		
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		w3CancelConfirm.dismiss();
		System.out.println("Confirm popup Cancelled  Sucessfully");
		
		driver.close();
		driver.quit();
	}
}
