
/**********************************************************************************************************************
Tester Name   : Shruti Pandey                   ClassName    : LoginPurchaseForeignCurrencyLogout_AlertHandle_1

Project Name  : Assignment3					    Scenario     : 1

Version       : 1.0

Date Created  : 30/12/2021                      Date Updated :


 ************************************************************************************************************************/
package assignments;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPurchaseForeignCurrencyLogout_AlertHandle_1 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");

		// open browser
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// open url
		driver.get("http://zero.webappsecurity.com/");
		
		driver.findElement(By.xpath("//button[@id='signin_button']")).click();

		driver.findElement(By.xpath("//input[@name ='user_login' ]")).sendKeys("username");

		driver.findElement(By.xpath("//input[contains(@id,'password')]")).sendKeys("password");
		
		driver.findElement(By.cssSelector("[name = 'submit']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		if(driver.findElement(By.cssSelector("button#details-button")).isDisplayed()) {
		driver.findElement(By.cssSelector("button#details-button")).click();
		driver.findElement(By.id("proceed-link")).click();
		}
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.linkText("Pay Bills")).click();
		//Explicit Wait
		WebDriverWait ewait = new WebDriverWait(driver, 5);
		ewait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(text(),'Purchase Foreign Currency')]")));
		

		driver.findElement(By.linkText("Purchase Foreign Currency")).click();
		ewait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h2[contains(text(),'Purchase foreign currency cash')]"), "Purchase foreign currency cash"));
		//driver.findElement(By.linkText("Purchase Foreign Currency")).click();
	
		driver.findElement(By.xpath("//input[@id='purchase_cash']")).click();
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//switching to alert
		Alert purchaseAlert = driver.switchTo().alert();
		String alertText = purchaseAlert.getText();
		System.out.println("You are getting Alert :" + alertText);
		assertEquals(alertText, "Please, ensure that you have filled all the required fields with valid values.","Alert test Failed because text doesn't match");
		purchaseAlert.accept();
		System.out.println("Alert Accepted Successfully");
		
		driver.findElement(By.xpath(".//body/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[3]/a[1]")).click();
		
		//logout
		driver.findElement(By.xpath("//a[contains(@id,'logout')]")).click();
		System.out.println("User Logged out successfully");
		
		driver.close();
		driver.quit();
		
	}

}
