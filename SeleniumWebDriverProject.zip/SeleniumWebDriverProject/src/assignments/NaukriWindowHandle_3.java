/**********************************************************************************************************************
Tester Name   : Shruti Pandey                   ClassName    : NaukriWindowHandle_3

Project Name  : Assignment3					    Scenario     : 3

Version       : 1.0

Date Created  : 30/12/2021                      Date Updated :


 ************************************************************************************************************************/

package assignments;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NaukriWindowHandle_3 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		//open url
		driver.get("https://www.naukri.com/");
		System.out.println(driver.getTitle());
		
		//wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
		String parentWinHandle = driver.getWindowHandle();
		System.out.println(parentWinHandle);
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//body/div[@id='root']/div[3]/div[3]/div[1]/div[1]/ul[1]/li[4]/a[1]/img[1]")).click();
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//windowhandles	
		Set <String> handles = driver.getWindowHandles();
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		System.out.println( handles);
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//first loops : parent ,   second loop :  child window
		for(String h : handles) {
			System.out.println("-----------The value of current handle is------"+ h);
			driver.switchTo().window(h);
			String Title = driver.getTitle();
			System.out.println("Title : " + Title);
			
			//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			if(driver.getTitle().contains("Labcorp jobs in India | Careers at Labcorp Drug Development") ){
				System.out.println("I have entered inside child window");
				driver.findElement(By.xpath("//header/div[1]/div[1]/ul[1]/li[6]/a[1]")).click();
				break;
			}
			
			//Just commenting to use one condition but both can be used-----------NOTE----------
			//we can use below loop also -- it will display all iterate through all child window
			/*
			if(driver.getTitle().contains("Labcorp jobs in India | Careers at Labcorp Drug Development") ){
				System.out.println("I have entered inside child window");
				driver.findElement(By.xpath("//header/div[1]/div[1]/ul[1]/li[6]/a[1]")).click();
				driver.switchTo().window(h);
			}*/

		}
		
		//go back to parentwindow
		driver.switchTo().window(parentWinHandle);
		System.out.println(" Switched back to Parent Window successfully :"+driver.getTitle());
		
		//close and quit driver
		driver.close();
		driver.quit();
	}

}
