package seleniumbasics;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locators {

	public static void main(String[] args)  {
		//we can define this path in env variables but once we change the location it will not work.
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		//open url
		driver.get("http://zero.webappsecurity.com/");
		
		//########### Locators ##############
		
		//-----By classname -----not to used as not best supported by selenium 
		
		driver.findElement(By.className("search-query")).sendKeys("online banking");
		
		//------ By ID --------
		
		driver.findElement(By.id("signin_button")).click();
		
		//---By name---
		
		driver.findElement(By.name("user_login")).sendKeys("username");
		
		//---By linkText------
		
//		driver.findElement(By.linkText("Forgot your password ?")).click();
//		Thread.sleep(2000);
		
		//----By Partial link text---
		driver.findElement(By.partialLinkText("Forgot")).click();
		
		//-----tagname must be unique in webpage-------
		driver.findElement(By.linkText("Zero Bank")).click();
		driver.findElement(By.tagName("button")).click();
		
		//#############CSS locators ##################
		//---By id ------------
		driver.findElement(By.cssSelector("#user_login")).sendKeys("username");
		
		//-------By attribute--------[attribute=value]
		driver.findElement(By.cssSelector("[type='password']")).sendKeys("password");
		
		
		driver.findElement(By.linkText("Zero Bank")).click();
		
		//=====by class name css----> .classname----
		driver.findElement(By.cssSelector(".search-query")).sendKeys("Fund Transfer");
		
		//-----By tag css ------tag---
		driver.findElement(By.cssSelector("button")).click();
		
		//------By tag+id ---css-->tag#id
		driver.findElement(By.cssSelector("input#user_login")).sendKeys("username");
		
		//------By tag+class ---css-->tag.classname
		driver.findElement(By.cssSelector("i.icon-question-sign")).click();
		
		//------By tag+attribute ---css-->tag[attribute=value]
		driver.findElement(By.cssSelector("input[name ='user_password']")).sendKeys("password");

		//------By tag+id+attribute ---css-->tag#id[attribute=value]
		driver.findElement(By.cssSelector("input#user_remember_me[name='user_remember_me']")).click();
		
		driver.findElement(By.cssSelector("[name = 'submit']")).click();
		driver.findElement(By.id("details-button")).click();
		driver.findElement(By.id("proceed-link")).click();
		
		driver.findElement(By.linkText("Pay Bills")).click();
		
		//------By tag+class+attribute ---css-->tag.classname[attribute=value]
		driver.findElement(By.cssSelector("input.span1[required='required']")).sendKeys("90");
		
		//------By tag+class+id ---css-->tag.classname#id
		driver.findElement(By.cssSelector("input.span4#sp_description")).sendKeys("Pay bills for cc");
		
		//------By tag+class+id+attribute ---css-->tag.classname#id[attribute=value]
		WebElement amountbox =   driver.findElement(By.cssSelector("input.span1#sp_amount[type='text']"));
		amountbox.clear();
		amountbox.sendKeys("50");

		//close browser
		driver.close();
		System.out.println("Driver closed successfuly");
		//kill driver
		driver.quit();

	}

}
