package seleniumbasics;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CheckboxesRadioButtonsAndSelectbox {

	public static void main(String[] args)  {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		//open url
		driver.get("http://zero.webappsecurity.com/");
		
		driver.findElement(By.id("signin_button")).click();
		
		driver.findElement(By.xpath("//input[@name ='user_login' ]")).sendKeys("username");

		driver.findElement(By.xpath("//input[contains(@id,'password')]")).sendKeys("password");
		
		//#########Working with checkbox############
		//click on check box
		WebElement rememberMeCheckbox =  driver.findElement(By.id("user_remember_me"));
		//rememberMeCheckbox.click();
		
		boolean rmcIsSelected = rememberMeCheckbox.isSelected();
		boolean rmcIsDisplayed = rememberMeCheckbox.isDisplayed();
		boolean rmcIsEnabled = rememberMeCheckbox.isEnabled();
		
//		if(!rmcIsSelected)
//		{
//			rememberMeCheckbox.click();
//			System.out.println("Remember me check box was not checked , I have checked it now.");
//		}else {
//			System.out.println("The Remember me check box is already checked!");
//		}
		
		if(rmcIsDisplayed) {
			System.out.println("The checkbox is displayed");
			if(rmcIsEnabled) {
				System.out.println("checkbox is Enabled");
				if(rmcIsSelected) {
					System.out.println("checkbox is selected");
				}else {
					rememberMeCheckbox.click();
					System.out.println("Check was not checked.I have checked now");
					}
			}
			else {
					System.out.println("Check box is not enabled");
				}
			}else {
				System.out.println("Check box is not displayed");
			}
		
		//log in to application - click on submit
		driver.findElement(By.name("submit")).click();
		
		driver.findElement(By.id("details-button")).click();
		driver.findElement(By.id("proceed-link")).click();
		//Thread.sleep(2000);
		
		//Explicit wait
		WebDriverWait ewait = new WebDriverWait(driver, 10);
		
		
		
		//Navigate to pay bills and purchase foreign currency
		driver.findElement(By.linkText("Pay Bills")).click();
		ewait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(text(),'Purchase Foreign Currency')]")));
		//Thread.sleep(2000);
		
		driver.findElement(By.linkText("Purchase Foreign Currency")).click();
		ewait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h2[contains(text(),'Purchase foreign currency cash')]"), "Purchase foreign currency cash"));
		//Thread.sleep(2000);

		//-----Working with Radio buttons----
		WebElement radiobutton= driver.findElement(By.id("pc_inDollars_true"));
		
		boolean dollarIsSelected = radiobutton.isSelected();
		
		if(!dollarIsSelected) {
			radiobutton.click();
			System.out.println("Radio buton was not selected I have selected US Dollar radio button");
		}
		//Thread.sleep(2000);
		
		//-----------Select boxes------------
		WebElement currency = driver.findElement(By.id("pc_currency"));
		
		
//      Select sel1 = new Select(driver.findElement(By.id("pc_currency")));
//      new Select(driver.findElement(By.id("pc_currency"))).selectByVisibleText("Switzerland (franc)");
		
		Select sel = new Select(currency);
		sel.selectByVisibleText("Denmark (krone)");
		//Thread.sleep(2000);

		sel.selectByValue("GBP");
		//Thread.sleep(2000);

		sel.selectByIndex(4);
		//Thread.sleep(2000);

		
		driver.close();
		driver.quit();
		
	
	}

}
