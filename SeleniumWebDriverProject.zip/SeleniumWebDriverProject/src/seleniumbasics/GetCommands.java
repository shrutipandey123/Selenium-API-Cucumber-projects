package seleniumbasics;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetCommands {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		
		//open url
		driver.get("http://zero.webappsecurity.com/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		//title
		String title = driver.getTitle();
		System.out.println(title);
		
		//Page Source
		System.out.println("-------------");
		System.out.println(driver.getPageSource());
		
		System.out.println("=========");
		
		driver.findElement(By.id("onlineBankingMenu")).click();
		
		//get url
		String url = driver.getCurrentUrl();
		System.out.println(url);
		
		//Get Text ---> for e.g. - headers, error messages (dynamic texts) ----> first locate element and then get text.
		String header= driver.findElement(By.id("money_map_link")).getText();		
		System.out.println(header);
		
		driver.navigate().to("http://zero.webappsecurity.com/login.html");
		driver.findElement(By.name("submit")).click();
		String erroMsg = driver.findElement(By.xpath("//form[@id='login_form']/div[1]")).getText();
		System.out.println(erroMsg);
		
		System.out.println("==========");
		
		//get Attribute
		
		WebElement passbox = driver.findElement(By.name("user_password"));
		String typeOfPassbox = passbox.getAttribute("type");
		
		//both this classes are different
		System.out.println(passbox.getAttribute("class"));
		//getClass
		System.out.println(passbox.getClass());
				
		driver.close();
		driver.quit();
	}

}
