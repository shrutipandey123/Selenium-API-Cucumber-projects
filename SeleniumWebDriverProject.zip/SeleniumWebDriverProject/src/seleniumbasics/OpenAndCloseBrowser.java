package seleniumbasics;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class OpenAndCloseBrowser {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		
		//open url
		driver.get("http://zero.webappsecurity.com/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		//close browser
		driver.close();
		
		//kill driver
		driver.quit();
		

	}

}
