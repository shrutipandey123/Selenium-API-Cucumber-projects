package seleniumbasics;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChropathLocators {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		
		//open url
		driver.get("http://zero.webappsecurity.com/");
		
		//########XPATH#############
		
		//abs xpath
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[1]/form[1]/input[1]")).sendKeys("hello");
		
		//rel xpath
		driver.findElement(By.xpath("//button[@id='signin_button']")).click();
		
		//xpath = tag + attribute ==  //tag[@attribute = 'value']
		driver.findElement(By.xpath("//input[@name ='user_login' ]")).sendKeys("username");
		//Thread.sleep(2000);
		
		//xpath with * sign
		driver.findElement(By.xpath("//*[@type='text' ]")).clear();
		//Thread.sleep(2000);
		
		//xpath with . sign
		driver.findElement(By.xpath(".//input[@name='user_login']")).sendKeys("username");
		
		//xpath with contains ===> contains(@attribute,'value')
		driver.findElement(By.xpath("//input[contains(@id,'password')]")).sendKeys("password");
		//Thread.sleep(2000);
		
		//xpath with contains() + href + indexing, index starts with one
//		driver.findElement(By.xpath("//a[contains(@href,'about/legal/')][2]")).click();
//		Thread.sleep(2000);
		
		//xpath with contains() with text
		driver.findElement(By.xpath("//a[contains(text(),'Forgot')]")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Zero Bank')]")).click();

	
		//xpath with contains + images
		driver.findElement(By.xpath("//img[contains(@src,'main_carousel_1')]")).click();
		//Thread.sleep(2000);
		//close and quit
		driver.close();
		driver.quit();
	}

}
