package seleniumbasics;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FramesAndWindows {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		//open url
		driver.get("http://the-internet.herokuapp.com/iframe");
				
		//########## Working with Frames ########
		
		WebElement  iFrame1 =  driver.findElement(By.id("mce_0_ifr"));
		
		driver.switchTo().frame(iFrame1);
		//Thread.sleep(2000);

		WebElement textArea1 =   driver.findElement(By.id("tinymce"));
		textArea1.clear();
		//Thread.sleep(2000);
		textArea1.sendKeys("This my new text");
		//Thread.sleep(2000);
		driver.switchTo().defaultContent();
		//Thread.sleep(2000);
		// ########### Working with Windows Handle#########
		
		driver.get("https://the-internet.herokuapp.com/windows");
		//Thread.sleep(2000);

		
		//Always String ---imp
		String parentWinHandle = driver.getWindowHandle();
		System.out.println(parentWinHandle);
		
		driver.findElement(By.linkText("Click Here")).click();
		//Thread.sleep(2000);

		//use here collection to handle next or other multiple windows
		//windowhandles
		
		Set <String> handles = driver.getWindowHandles();
		//Thread.sleep(2000);
		
		System.out.println( handles);
		//Thread.sleep(2000);
		
		//first loop swith to parent second loop child window
		for(String h : handles) {
			System.out.println("The value of current handle is------"+ h);
			driver.switchTo().window(h);
			System.out.println(driver.getTitle());
			//Thread.sleep(2000);
		}
		
		//Thread.sleep(2000);
//		for(String h : handles) {
//			System.out.println("The value of current handle is------"+ h);
//			if(h != parentWinHandle) {
//				driver.switchTo().window(h);
//				System.out.println(driver.getTitle());
//				Thread.sleep(2000);
//			}
//		}
		
//go back to parentwindow--after for loop
driver.switchTo().window(parentWinHandle);
//Thread.sleep(2000);

		driver.close();
		driver.quit();
	}

}
