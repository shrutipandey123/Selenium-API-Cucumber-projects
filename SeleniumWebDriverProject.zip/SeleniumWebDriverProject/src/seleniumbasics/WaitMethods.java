package seleniumbasics;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitMethods {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		//implicit wait
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	
		driver.manage().window().maximize();
		
		//open url
		driver.get("http://zero.webappsecurity.com/");
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.tagName("button")).click();
	//	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.cssSelector("#user_login")).sendKeys("username");
		driver.findElement(By.cssSelector("[type='password']")).sendKeys("password");
		
		driver.findElement(By.cssSelector("[name = 'submit']")).click();
		
		if(driver.findElement(By.cssSelector("button#details-button")).isDisplayed()) {
		driver.findElement(By.cssSelector("button#details-button")).click();
		driver.findElement(By.id("proceed-link")).click();
		}
		
		//Explicit wait
		WebDriverWait ewait = new WebDriverWait(driver, 10);
		ewait.until(ExpectedConditions.titleContains("Zero - Account Summary"));
		
		//close
		driver.close();
		driver.quit();
		
	}

}
