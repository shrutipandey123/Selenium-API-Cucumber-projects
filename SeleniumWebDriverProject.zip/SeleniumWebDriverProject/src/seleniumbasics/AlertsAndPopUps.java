package seleniumbasics;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertsAndPopUps {

	public static void main(String[] args)  {
		
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//open url
		driver.get("http://the-internet.herokuapp.com/javascript_alerts");
		
		//#####Alerts#########
		
		driver.findElement(By.xpath("//button[contains(text(),'Click for JS Alert')]")).click();
		
		Alert jsAlert = driver.switchTo().alert();
		String alertText = jsAlert.getText();
		System.out.println("The Text on the JS Alert is :" +alertText);
		jsAlert.accept();
		
		assertEquals(driver.findElement(By.id("result")).getText(), "You successfully clicked an alert","Alert test Failed");
		
		//########Confirmation##########
		
		//click on confirm ok-----------
		driver.findElement(By.xpath("//button[contains(text(),'Click for JS Confirm')]")).click();
		
		Alert jsConfirm = driver.switchTo().alert();
		String confirmText = jsConfirm.getText();
		System.out.println("The Text on the confirmation popup is :" +confirmText);
		//Thread.sleep(2000);
		
		jsConfirm.accept();
		
		assertEquals(driver.findElement(By.id("result")).getText(), "You clicked: Ok","Confirmation Test Failed");
		
		//click on confirm cancel popup---------
		driver.findElement(By.xpath("//button[contains(text(),'Click for JS Confirm')]")).click();		
		Alert jsCancel = driver.switchTo().alert();
		//Thread.sleep(2000);
		
		jsCancel.dismiss();
		
		assertEquals(driver.findElement(By.id("result")).getText(), "You clicked: Cancel","Confirmation Test Failed");
		
		
		//##########Prompt#############
		//click on ok prompt
		driver.findElement(By.xpath("//button[contains(text(),'Click for JS Prompt')]")).click();
		Alert jsPrompt = driver.switchTo().alert();
		System.out.println(jsPrompt.getText());
		jsPrompt.sendKeys("This a prompt");
		//Thread.sleep(2000);
		jsPrompt.accept();
		assertEquals(driver.findElement(By.id("result")).getText(), "You entered: This a prompt"," Test Failed");

		//click on cancel prompt
		driver.findElement(By.xpath("//button[contains(text(),'Click for JS Prompt')]")).click();
		Alert jsPromptCancel = driver.switchTo().alert();
		System.out.println(jsPromptCancel.getText());
		jsPromptCancel.sendKeys("This a prompt");
		//Thread.sleep(2000);
		jsPrompt.dismiss();
		assertEquals(driver.findElement(By.id("result")).getText(), "You entered: null"," Test Failed");

		
		//close and quit
		driver.close();
		driver.quit();
		
		//-------------
		/* Set<String> windows = driver.getWindowHandles(); 
System.out.println(windows); 
System.out.println("a1"); 
for (String window : windows) 
{ 
driver.switchTo().window(window); 
if (driver.getTitle().contains("Best Training & Certification Courses for Professionals | Edureka")) 
{ 
System.out.println("a2"); 
js.executeScript("window.scrollBy(0,1000)"); 
System.out.println("b1"); 
driver.findElement(By.xpath("//*[@id="allc_catlist"]/li[3]/a")).click(); 
driver.manage().window().setPosition(new Point(-2000, 0)); 
} 
} 
Thread.sleep(3000); 
Set<String> windows1 = driver.getWindowHandles(); 
System.out.println(windows1); 
System.out.println("a3"); 
for (String window : windows1) 
{ 
driver.switchTo().window(window); 
System.out.println("a4"); 
js.executeScript("window.scrollBy(0,400)"); 
}  */
		

	}

}
