package seleniumbasics;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NavigationCommands {

	public static void main(String[] args)  {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		//open url
		driver.get("http://zero.webappsecurity.com/");
		
		//########Navigation#########
		driver.findElement(By.id("onlineBankingMenu")).click();
		//Thread.sleep(1000);
		
		//backward navigation
		driver.navigate().back();
		
		//forward
		driver.navigate().forward();
		
		//referesh
		driver.navigate().refresh();
		
		//navigate to- different url
		driver.navigate().to("https://www.selenium.dev/");
		
		driver.get("http://zero.webappsecurity.com/");
		
		//close and quit
		driver.close();
		driver.quit();

	}

}
