package seleniumbasics;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

public class AssertionsAndVerification {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		//open url
		driver.get("http://zero.webappsecurity.com/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		
		//Validation
		String expectedTitle = "Zero - Personal Banking - Loans - Credit Cards";
		String actualTitle = driver.getTitle();
		
		//this is lot amount of code just for validation so just use testng ka assert method
//		if(actualTitle == expectedTitle) {
//			System.out.println("Pass");
//		}else {
//			System.out.println("Fail");
//			System.out.println(actualTitle);
//		}
		
		
		//#############Assertion###########
		//Hard Assert
		//assertEquals(actualTitle,expectedTitle);
		assertEquals(actualTitle,expectedTitle,"The Application is down and test Failed");
		
		
		//##########Verification###############
		
		//------Verify using try catch--------way1------
		
		//when we know something will throw error so handle it using
		//try catch block 
		//further execution will still continue after failure also
		try {
			String brand = driver.findElement(By.className("brand")).getText();
			assertEquals(brand, "Zero Bank","");
		} catch (AssertionError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//soft assert
		//------verify brand name i.e. zero bank----way2-----
		SoftAssert sa = new SoftAssert();
		String brand = driver.findElement(By.className("brand")).getText();
		sa.assertEquals(brand,"Zero Bank","Test Failed /n" );
		
		sa.assertAll();
		
		
		//not required below one
//		assertEquals(brand, "Zero Bank");
		
		
		//close and quit driver
		driver.close();
		driver.quit();
		

	}

}
