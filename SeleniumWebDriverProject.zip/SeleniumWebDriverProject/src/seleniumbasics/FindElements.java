package seleniumbasics;

import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FindElements {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//open browser
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		//open url
		driver.get("http://zero.webappsecurity.com/");
		
		String expectedTitle = "Zero - Personal Banking - Loans - Credit Cards";
		String actualTitle = driver.getTitle();
		
		//assertEquals(actualTitle,expectedTitle);
		assertEquals(actualTitle,expectedTitle,"The Application is down and test Failed");
		
		//collect all the links from page
		List <WebElement> links = driver.findElements(By.tagName("a"));
		System.out.println(links);
		
		//translate all the links in to kinktext to use the links
		String[] linkText = new String[links.size()];
		int i =0;
		
		for(WebElement l : links) {
			linkText[i] = l.getText();
			System.out.println(linkText[i]);
			i++;
		}
		
		//iterate and click on all the links
		for(String lt : linkText) {
			if(lt == "More Services") {
				driver.findElement(By.linkText(lt)).click();
				System.out.println(driver.getTitle());
				driver.navigate().back();
				assertEquals(actualTitle, expectedTitle);
			}else if(lt == "<" || lt == ">") {
				continue;
			}else {
				driver.findElement(By.linkText(lt)).click();
				System.out.println(driver.getTitle());
			}
		}
		
		driver.close();
		driver.quit();

	}

}
