package com.qa.zerobank.pages;

public class OnlineBankingPage {
	//No need to add anything for this scenario
}
