package com.zerobank.qa.TestRunners;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
 

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/java/com/zerobank/qa/Features",
        glue = {"src/test/java/com/zerobank/qa/TestCode"},
        plugin = {"pretty", "html:target/cucumber"},
        tags = {"@smoke and not @regression"}
 
        )
public class CucumberTestRunner {    
 
}