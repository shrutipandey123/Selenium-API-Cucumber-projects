package javabasics;

import java.util.Scanner;

public class BasicsClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//single line comments
		
		//print on console
		
		System.out.println("hello world");
		System.out.println("hello");
		
		//read from console
		Scanner userInput = new Scanner(System.in);
		
		System.out.println("what is your name?  ");
	
		String name = userInput.next();
		System.out.println("welcome " + name + "!");
		userInput.close();
		
		//escape sequence
		
		System.out.println("This is new line \n");
		System.out.println("This is tab \t\t escape sequence");
		System.out.println("This is quote \" escape sequence");
	}

}
