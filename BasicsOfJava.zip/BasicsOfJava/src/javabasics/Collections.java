package javabasics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;

public class Collections {

	public static void main(String[] args) {
		
		//######### Arrays ##############
		
		int[] numbers = new int[3];
		numbers[0] = 10;
		numbers[1] = 20;
		numbers[2] = 30;
		System.out.println(numbers);//wrong output
		//always use for loop to print array
		for(int i=0;i<numbers.length;i++)//length is the property of array 
		{
			System.out.println(numbers[i]);
		}
		
		//shortcut
		int[]num = {10,20,30,40};
		//System.out.println(num);
		for (int i :num) {
			System.out.println(i);
		}
		
		
		//########## Array class ######
		
		int[] numbers2 = {2,6,5,8};
		Arrays.sort(numbers2);
		String result = Arrays.toString(numbers2);
		System.out.println(result);
		
		
		//########## Multidimentional Array #########
		
		int a2[][] = new int[2][2];
		
		
		String [][]a3 = {{"00","10"},{"01","11"}};
		System.out.println(a3[1][1]);
		
		
		// ######### Array List #############
		
		ArrayList<String> a1 =new ArrayList<String>(10);
		a1.add("xyz");
		a1.add("yz");
		a1.add("ay");
		a1.add("xz");
		for(String i:a1) System.out.print(i);
		System.out.println();
		
		//simlpe arraylist
		ArrayList<Integer> aa = new ArrayList<>(Arrays.asList(1,2,3,4,5));
		for(Integer x:aa) System.out.println(x);
		System.out.println("=====================");
		
		//get value in list
		System.out.println(aa.get(1));
		
		System.out.println("=====================");
		
		//add a value at index
		aa.set(1,6);
		for(Integer x:aa) System.out.println(x);
		System.out.println("=====================");
		
		//delete value, delete all(delete aa.clear()
		aa.remove(3);
		for(Integer x:aa) System.out.println(x);
		
		//########## Linkedlist ###############
		//no size defined in linkedlist
		LinkedList<Integer> l1 = new LinkedList<Integer>();
		l1.add(1);
		l1.add(2);
		
		//add array to list
		l1.addAll(Arrays.asList(1,2,3,4,5));
		
		//Add to front (Add to last also)
		l1.addFirst(0);
		
		//check if in list
		System.out.println(l1.contains(4));
		
		//Get index for match
		System.out.println(l1.indexOf(4));
		
		//replace
		l1.set(0, 2);
		
		//get value
		//also getfirst and last
		System.out.println(l1.get(0));
		
		//Delete(clear() removes all
		l1.remove(1);
		
		//get size
		l1.size();
		
		//convert to array
		Object[] a0 = l1.toArray();
		
		
		
		
	}

}
