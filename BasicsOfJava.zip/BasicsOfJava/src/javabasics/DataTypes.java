package javabasics;

public class DataTypes {

	public static void main(String[] args) {
		
		//static final double favNumber = 1.6180;//this number is shareable means static, declared once
		//Primitive type
		//int
		int age = 20;
		System.out.println("My age is :"+age);
		age = 50;                    //we can change age as not static and final
		System.out.println("My age after 30 years :"+age);
		
		int hisAge = age;
		System.out.println("His age is :"+hisAge);
		
		//byte
		byte herAge = 22;
		System.out.println("Her age is "+ herAge);
		
		//short
		short s = 3333;
		System.out.println("SHort:"+s);
		
		
		//lomg
		long viewCount = 3_123_456L;
		System.out.println("Long view count is"+viewCount);
		
		//float
		float price = 10.99F;
		System.out.println("float is"+price);
		
		//char
		char letter = 'A';
		System.out.println("char is : "+letter);
		
		//boolean
		boolean isEligible = true;
		System.out.println("Boolean value: "+isEligible);
		
		//#########################
		System.out.println("Byte Max:" + Byte.MAX_VALUE);
		System.out.println("Byte Min:" + Byte.MIN_VALUE);
		System.out.println("CHar Max : "+ (Character.MAX_VALUE+0));
		System.out.println("CHar Min : "+ (Character.MIN_VALUE+0));
		System.out.println("INT MAX:"+ Integer.MAX_VALUE);
		System.out.println("INT Min:"+ Integer.MIN_VALUE);
		
		
		System.out.println("Byte Max: " +
                Byte.MAX_VALUE);       
        System.out.println("Byte Min: " +
                Byte.MIN_VALUE);
        System.out.println("Short Max: " +
                Short.MAX_VALUE);
        System.out.println("Short Min: " +
                Short.MIN_VALUE);
        System.out.println("Char Max: " +
                (Character.MAX_VALUE+0));
        System.out.println("Char Min: " +
                (Character.MIN_VALUE+0));
        System.out.println("Int Max: " +
                Integer.MAX_VALUE);
        System.out.println("Int Min: " +
                Integer.MIN_VALUE);
        System.out.println("Float Max: " +
                Float.MAX_VALUE);
        System.out.println("Float Min: " +
                Float.MIN_VALUE);
        System.out.println("Double Max: " +
                Double.MAX_VALUE);
        System.out.println("Double Min: " +
                Double.MIN_VALUE);
        System.out.println("Long Max: " +
                Long.MAX_VALUE);
        System.out.println("Long Min: " +
                Long.MIN_VALUE);
        
        
        //######################
        
     // Floating point precision 6 decimals
        float fNum = 1.1111111111111111F;
        float fNum2 = 1.1111111111111111F;
        System.out.println("Float : " +
                (fNum + fNum2));

        // Double precision 15 decimals
        double dblNum = 1.1111111111111111;
        double dblNum2 = 1.1111111111111111;
        System.out.println("Double : " +
                (dblNum + dblNum2));

        // Can use scientific notation
        double thousand = 1e+3;
        System.out.println(thousand);

        // You can define longs with _
        long bigNum = 123_456_789;
        
        
        
        //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
        //type casting - implicit - small to big
        //explicit- big to small
        
        //implicit
        short x = 1;
        int y = x;
        System.out.println("implicit casting: "+y);

        
        //explicit
        int ax = 1;
        short b = (short) ax;
        System.out.println("Explicit casting: "+b);
        		
        //Use (newType) otherwise
        double doub = 1.234;
        int aint = (int)doub;
        System.out.println(aint);
        
        
        long bigLong = 21474836470L;
        int bInt = (int) bigLong;
        System.out.println(bInt);
        
        //Use Wrapper class to convert to string
        String FavNum = Double.toString(1.618);
        System.out.println(FavNum);
        
        //Convert string to primitives with
        //Byte.parseByte, Boolean.parseBoolean,
        //and the same format for each type
        //except for chars
        int StrInt = Integer.parseInt("10");
        System.out.println(StrInt);
        
        
        
        

        
        
        
        

				
	}

}
