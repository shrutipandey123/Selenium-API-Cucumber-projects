package javabasics;

import java.util.Scanner;

public class Loops {

	public static void main(String[] args) {
		// for loop
		
		for(int i = 0; i < 5; i++)
		{
			System.out.println(i);
		}
		
		System.out.println("===================");
		
		//while loop
		
		int w = 0;
		while(w<20) {
			
			if(w%2  == 0) {
				System.out.println(w);
				w++;
				
				//jump back to the beginning of loop
				continue;
				
			}
			
			if(w>=10) {
				//stop loop
				break;
			}
			w++;
		}
		
		//do while-------execute atleast once
		Scanner sc = new Scanner(System.in);
		int secretNum = 7;
		int guess = 0;
		do {
			System.out.println("Guess : ");
			if(sc.hasNextInt()) {
				guess = sc.nextInt();
				}
		}while(secretNum!= guess);
		System.out.println("You guessed it");
		sc.close();
	}

}
