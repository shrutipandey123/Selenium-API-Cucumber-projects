package javabasics;

public class StringOperations {
	
	public static void main(String[] args) {

		String name = "Shruti";
		System.out.println(name);
		
		
		//concatinate
	String fullname = name + "Pandey";
	System.out.println("My full name is: " + fullname);
	
	//conversion is automatic when using primitives
	String sDog = "k"+ 9;
	System.out.println(sDog);
	
	//Get character at index
	System.out.println(fullname.charAt(0));
	
	//Does it contain shruti
	System.out.println(fullname.contains("Shruti"));
	
	//get index of match
	System.out.println((fullname.indexOf("i")));
	
	//Number of characters
	System.out.println(fullname.length());
	
	//If equals output is 0,If output is+ve number, means x times greater . If output is -ve it is x times smaller.
	//compareToIgnoreCase
	System.out.println(fullname.compareTo("ABC"));//compares unicode of characters
	
	//Replace matches
	//replaceFirst
	System.out.println(fullname.replace("Shruti", "SHRUTI"));
	
	//get string at indexes
	System.out.println(fullname.substring(0,5));
	
	//turn string to array
	for(String x: fullname.split("")) {
		System.out.println(x);
	}

		
	}
	
}
