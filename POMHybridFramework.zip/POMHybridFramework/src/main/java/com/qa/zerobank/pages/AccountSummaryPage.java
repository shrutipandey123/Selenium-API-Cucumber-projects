package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class AccountSummaryPage extends TestBase {
	
	//object repository
	
	@FindBy(id = "account_summary_tab")
	WebElement accountSummaryTab;
	
	@FindBy(id = "account_activity_tab")
	WebElement accountActivityTab;
	
	@FindBy(id = "transfer_funds_tab")
	WebElement transferFundTab;
	
	@FindBy(id = "pay_bills_tab")
	WebElement payBillsTab;
	
	@FindBy(id = "money_map_tab")
	WebElement moneyMapTab;
	
	@FindBy(id = "online_statements_tab")
	WebElement onlineStatementsTab;
	
	
	//constructor
	
	public  AccountSummaryPage() {
		
		PageFactory.initElements(driver, this);
	}
	
	 
	//assert title
	
	public void assertAccountSummaryPageTitle() {
		 assertEquals(driver.getTitle(), "Zero - Account Summary");
	 }
	 

}
