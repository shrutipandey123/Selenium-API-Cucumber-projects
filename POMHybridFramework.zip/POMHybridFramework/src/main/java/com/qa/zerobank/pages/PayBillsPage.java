package com.qa.zerobank.pages;

public class PayBillsPage {

}
