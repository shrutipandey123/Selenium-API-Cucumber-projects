package com.qa.zerobank.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;

public class LogInPageTestcases extends  TestBase {
	
	HomePage  homePage;
	LogInPage logInPage;
	AccountSummaryPage accountsummarypage;
	
	public LogInPageTestcases() {
		super();//when you want to initialize or call super class, hwere base class is super class so it willinvoke testbase class properties thing which we have have written inside constructor TestBase
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		homePage = new HomePage();
		logInPage = new LogInPage();
	}
	
	@AfterMethod
	public void cleanUp() {
		//close driver
		driver.close();
		driver.quit();
	}
	
	@Test
	public void validateLogInPage() {
		logInPage = homePage.clickOnSignInButton();
		logInPage.assertLogInPageTitle();
	}
	
	@Test
	public void validateLogInFunctionality() {
		logInPage = homePage.clickOnSignInButton();
		accountsummarypage = logInPage.logIn();
		accountsummarypage.assertAccountSummaryPageTitle();
	}
	
	
	
	

}
